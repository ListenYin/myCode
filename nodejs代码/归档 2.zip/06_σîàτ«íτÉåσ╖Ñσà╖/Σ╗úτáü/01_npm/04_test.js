const math = require('atguigu_math');

console.log(math.add(1, 2))