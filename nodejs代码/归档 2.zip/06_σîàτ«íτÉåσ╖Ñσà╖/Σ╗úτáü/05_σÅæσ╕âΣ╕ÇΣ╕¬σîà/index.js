//加法
function add(a,b){
  return a + b;
}

//减法
function sub(a, b){
  return a - b;
}

//暴露
module.exports = {
  add,
  sub
}