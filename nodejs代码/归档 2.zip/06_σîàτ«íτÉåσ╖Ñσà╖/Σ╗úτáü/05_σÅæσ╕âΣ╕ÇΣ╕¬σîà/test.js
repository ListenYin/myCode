const math = require('./index');

console.log(math.sub(3, 2))