//导入模块
const me = require('./me.js');

//输出 me
console.log(me);
// me.tiemo();
// me.niejiao();