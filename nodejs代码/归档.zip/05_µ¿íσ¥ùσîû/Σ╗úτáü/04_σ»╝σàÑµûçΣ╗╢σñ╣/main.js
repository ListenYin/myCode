//导入
const m = require('./module');

console.log(m);