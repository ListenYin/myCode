//导入模块
const tiemo = require('./me.js');

//调用函数
tiemo();