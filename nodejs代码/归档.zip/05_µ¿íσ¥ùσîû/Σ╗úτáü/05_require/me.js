const test = {
  name: '尚硅谷'
}

module.exports = test;

//输出
// console.log(arguments.callee.toString());
console.log(test);

