//导入 me.js
const m = require('./me.js');
const m2 = require('./me.js');
