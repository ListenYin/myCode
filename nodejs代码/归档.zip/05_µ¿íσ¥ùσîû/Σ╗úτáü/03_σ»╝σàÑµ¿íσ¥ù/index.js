//导入模块  // fs 
// const tiemo = require('./me.js');

//省略后缀 JS
// const tiemo = require('./me');

//导入 JSON 文件
// const duanzi = require('./duanzi');
// console.log(duanzi);//对象

//导入其他类型的文件
const test = require('./test');

console.log(test);
// //调用函数
// tiemo();