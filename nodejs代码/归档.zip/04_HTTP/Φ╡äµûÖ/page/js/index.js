//获取图片
let img = document.querySelector('img');
//绑定事件
img.onclick = function(){
  alert('尚硅谷前端欢迎你')
}